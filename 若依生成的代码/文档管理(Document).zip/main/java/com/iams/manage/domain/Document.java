package com.iams.manage.domain;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.iams.common.annotation.Excel;
import com.iams.common.core.domain.BaseEntity;

/**
 * 文档管理对象 tb_document
 * 
 * @author zhjm
 * @date 2025-01-05
 */
public class Document extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** 主键 */
    @Excel(name = "主键")
    private Long id;

    /** 目录内序号 */
    private Long xuhao;

    /** 文件名称 */
    @Excel(name = "文件名称")
    private String name;

    /** 所在目录 */
    @Excel(name = "所在目录")
    private Long directoryId;

    /** 文件类型 */
    @Excel(name = "文件类型")
    private String fileType;

    /** 文件大小(Kb) */
    @Excel(name = "文件大小(Kb)")
    private Long fileSize;

    /** 存放位置 */
    @Excel(name = "存放位置")
    private String location;

    /** 文件内容 */
    private String content;

    /** 真实性 */
    @Excel(name = "真实性")
    private Integer authenticity;

    /** 完整性 */
    @Excel(name = "完整性")
    private Integer integrity;

    /** 可用性 */
    @Excel(name = "可用性")
    private Integer availability;

    /** 安全性 */
    @Excel(name = "安全性")
    private Integer security;

    public void setId(Long id) 
    {
        this.id = id;
    }

    public Long getId() 
    {
        return id;
    }
    public void setXuhao(Long xuhao) 
    {
        this.xuhao = xuhao;
    }

    public Long getXuhao() 
    {
        return xuhao;
    }
    public void setName(String name) 
    {
        this.name = name;
    }

    public String getName() 
    {
        return name;
    }
    public void setDirectoryId(Long directoryId) 
    {
        this.directoryId = directoryId;
    }

    public Long getDirectoryId() 
    {
        return directoryId;
    }
    public void setFileType(String fileType) 
    {
        this.fileType = fileType;
    }

    public String getFileType() 
    {
        return fileType;
    }
    public void setFileSize(Long fileSize) 
    {
        this.fileSize = fileSize;
    }

    public Long getFileSize() 
    {
        return fileSize;
    }
    public void setLocation(String location) 
    {
        this.location = location;
    }

    public String getLocation() 
    {
        return location;
    }
    public void setContent(String content) 
    {
        this.content = content;
    }

    public String getContent() 
    {
        return content;
    }
    public void setAuthenticity(Integer authenticity) 
    {
        this.authenticity = authenticity;
    }

    public Integer getAuthenticity() 
    {
        return authenticity;
    }
    public void setIntegrity(Integer integrity) 
    {
        this.integrity = integrity;
    }

    public Integer getIntegrity() 
    {
        return integrity;
    }
    public void setAvailability(Integer availability) 
    {
        this.availability = availability;
    }

    public Integer getAvailability() 
    {
        return availability;
    }
    public void setSecurity(Integer security) 
    {
        this.security = security;
    }

    public Integer getSecurity() 
    {
        return security;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("id", getId())
            .append("xuhao", getXuhao())
            .append("name", getName())
            .append("directoryId", getDirectoryId())
            .append("fileType", getFileType())
            .append("fileSize", getFileSize())
            .append("location", getLocation())
            .append("content", getContent())
            .append("authenticity", getAuthenticity())
            .append("integrity", getIntegrity())
            .append("availability", getAvailability())
            .append("security", getSecurity())
            .append("createTime", getCreateTime())
            .append("createBy", getCreateBy())
            .append("updateTime", getUpdateTime())
            .append("updateBy", getUpdateBy())
            .append("remark", getRemark())
            .toString();
    }
}
