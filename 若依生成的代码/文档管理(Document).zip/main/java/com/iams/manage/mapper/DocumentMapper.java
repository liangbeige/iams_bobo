package com.iams.manage.mapper;

import java.util.List;
import com.iams.manage.domain.Document;

/**
 * 文档管理Mapper接口
 * 
 * @author zhjm
 * @date 2025-01-05
 */
public interface DocumentMapper 
{
    /**
     * 查询文档管理
     * 
     * @param id 文档管理主键
     * @return 文档管理
     */
    public Document selectDocumentById(Long id);

    /**
     * 查询文档管理列表
     * 
     * @param document 文档管理
     * @return 文档管理集合
     */
    public List<Document> selectDocumentList(Document document);

    /**
     * 新增文档管理
     * 
     * @param document 文档管理
     * @return 结果
     */
    public int insertDocument(Document document);

    /**
     * 修改文档管理
     * 
     * @param document 文档管理
     * @return 结果
     */
    public int updateDocument(Document document);

    /**
     * 删除文档管理
     * 
     * @param id 文档管理主键
     * @return 结果
     */
    public int deleteDocumentById(Long id);

    /**
     * 批量删除文档管理
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteDocumentByIds(Long[] ids);
}
