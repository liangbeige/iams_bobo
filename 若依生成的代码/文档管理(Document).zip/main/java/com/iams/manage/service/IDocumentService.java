package com.iams.manage.service;

import java.util.List;
import com.iams.manage.domain.Document;

/**
 * 文档管理Service接口
 * 
 * @author zhjm
 * @date 2025-01-05
 */
public interface IDocumentService 
{
    /**
     * 查询文档管理
     * 
     * @param id 文档管理主键
     * @return 文档管理
     */
    public Document selectDocumentById(Long id);

    /**
     * 查询文档管理列表
     * 
     * @param document 文档管理
     * @return 文档管理集合
     */
    public List<Document> selectDocumentList(Document document);

    /**
     * 新增文档管理
     * 
     * @param document 文档管理
     * @return 结果
     */
    public int insertDocument(Document document);

    /**
     * 修改文档管理
     * 
     * @param document 文档管理
     * @return 结果
     */
    public int updateDocument(Document document);

    /**
     * 批量删除文档管理
     * 
     * @param ids 需要删除的文档管理主键集合
     * @return 结果
     */
    public int deleteDocumentByIds(Long[] ids);

    /**
     * 删除文档管理信息
     * 
     * @param id 文档管理主键
     * @return 结果
     */
    public int deleteDocumentById(Long id);
}
