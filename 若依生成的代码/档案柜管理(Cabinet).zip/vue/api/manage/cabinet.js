import request from '@/utils/request'

// 查询档案柜管理列表
export function listCabinet(query) {
  return request({
    url: '/manage/cabinet/list',
    method: 'get',
    params: query
  })
}

// 查询档案柜管理详细
export function getCabinet(id) {
  return request({
    url: '/manage/cabinet/' + id,
    method: 'get'
  })
}

// 新增档案柜管理
export function addCabinet(data) {
  return request({
    url: '/manage/cabinet',
    method: 'post',
    data: data
  })
}

// 修改档案柜管理
export function updateCabinet(data) {
  return request({
    url: '/manage/cabinet',
    method: 'put',
    data: data
  })
}

// 删除档案柜管理
export function delCabinet(id) {
  return request({
    url: '/manage/cabinet/' + id,
    method: 'delete'
  })
}
