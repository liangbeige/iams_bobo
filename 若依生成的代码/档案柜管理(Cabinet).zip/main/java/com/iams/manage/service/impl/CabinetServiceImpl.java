package com.iams.manage.service.impl;

import java.util.List;
import com.iams.common.utils.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.iams.manage.mapper.CabinetMapper;
import com.iams.manage.domain.Cabinet;
import com.iams.manage.service.ICabinetService;

/**
 * 档案柜管理Service业务层处理
 * 
 * @author zhjm
 * @date 2025-01-06
 */
@Service
public class CabinetServiceImpl implements ICabinetService 
{
    @Autowired
    private CabinetMapper cabinetMapper;

    /**
     * 查询档案柜管理
     * 
     * @param id 档案柜管理主键
     * @return 档案柜管理
     */
    @Override
    public Cabinet selectCabinetById(Long id)
    {
        return cabinetMapper.selectCabinetById(id);
    }

    /**
     * 查询档案柜管理列表
     * 
     * @param cabinet 档案柜管理
     * @return 档案柜管理
     */
    @Override
    public List<Cabinet> selectCabinetList(Cabinet cabinet)
    {
        return cabinetMapper.selectCabinetList(cabinet);
    }

    /**
     * 新增档案柜管理
     * 
     * @param cabinet 档案柜管理
     * @return 结果
     */
    @Override
    public int insertCabinet(Cabinet cabinet)
    {
        cabinet.setCreateTime(DateUtils.getNowDate());
        return cabinetMapper.insertCabinet(cabinet);
    }

    /**
     * 修改档案柜管理
     * 
     * @param cabinet 档案柜管理
     * @return 结果
     */
    @Override
    public int updateCabinet(Cabinet cabinet)
    {
        cabinet.setUpdateTime(DateUtils.getNowDate());
        return cabinetMapper.updateCabinet(cabinet);
    }

    /**
     * 批量删除档案柜管理
     * 
     * @param ids 需要删除的档案柜管理主键
     * @return 结果
     */
    @Override
    public int deleteCabinetByIds(Long[] ids)
    {
        return cabinetMapper.deleteCabinetByIds(ids);
    }

    /**
     * 删除档案柜管理信息
     * 
     * @param id 档案柜管理主键
     * @return 结果
     */
    @Override
    public int deleteCabinetById(Long id)
    {
        return cabinetMapper.deleteCabinetById(id);
    }
}
