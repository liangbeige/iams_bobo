import request from '@/utils/request'

// 查询档案管理列表
export function listArchive(query) {
  return request({
    url: '/manage/archive/list',
    method: 'get',
    params: query
  })
}

// 查询档案管理详细
export function getArchive(id) {
  return request({
    url: '/manage/archive/' + id,
    method: 'get'
  })
}

// 新增档案管理
export function addArchive(data) {
  return request({
    url: '/manage/archive',
    method: 'post',
    data: data
  })
}

// 修改档案管理
export function updateArchive(data) {
  return request({
    url: '/manage/archive',
    method: 'put',
    data: data
  })
}

// 删除档案管理
export function delArchive(id) {
  return request({
    url: '/manage/archive/' + id,
    method: 'delete'
  })
}
