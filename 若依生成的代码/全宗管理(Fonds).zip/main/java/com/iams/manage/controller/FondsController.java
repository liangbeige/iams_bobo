package com.iams.manage.controller;

import java.util.List;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.iams.common.annotation.Log;
import com.iams.common.core.controller.BaseController;
import com.iams.common.core.domain.AjaxResult;
import com.iams.common.enums.BusinessType;
import com.iams.manage.domain.Fonds;
import com.iams.manage.service.IFondsService;
import com.iams.common.utils.poi.ExcelUtil;
import com.iams.common.core.page.TableDataInfo;

/**
 * 全宗管理Controller
 * 
 * @author zhjm
 * @date 2025-01-05
 */
@RestController
@RequestMapping("/manage/fonds")
public class FondsController extends BaseController
{
    @Autowired
    private IFondsService fondsService;

    /**
     * 查询全宗管理列表
     */
    @PreAuthorize("@ss.hasPermi('manage:fonds:list')")
    @GetMapping("/list")
    public TableDataInfo list(Fonds fonds)
    {
        startPage();
        List<Fonds> list = fondsService.selectFondsList(fonds);
        return getDataTable(list);
    }

    /**
     * 导出全宗管理列表
     */
    @PreAuthorize("@ss.hasPermi('manage:fonds:export')")
    @Log(title = "全宗管理", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, Fonds fonds)
    {
        List<Fonds> list = fondsService.selectFondsList(fonds);
        ExcelUtil<Fonds> util = new ExcelUtil<Fonds>(Fonds.class);
        util.exportExcel(response, list, "全宗管理数据");
    }

    /**
     * 获取全宗管理详细信息
     */
    @PreAuthorize("@ss.hasPermi('manage:fonds:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(fondsService.selectFondsById(id));
    }

    /**
     * 新增全宗管理
     */
    @PreAuthorize("@ss.hasPermi('manage:fonds:add')")
    @Log(title = "全宗管理", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody Fonds fonds)
    {
        return toAjax(fondsService.insertFonds(fonds));
    }

    /**
     * 修改全宗管理
     */
    @PreAuthorize("@ss.hasPermi('manage:fonds:edit')")
    @Log(title = "全宗管理", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody Fonds fonds)
    {
        return toAjax(fondsService.updateFonds(fonds));
    }

    /**
     * 删除全宗管理
     */
    @PreAuthorize("@ss.hasPermi('manage:fonds:remove')")
    @Log(title = "全宗管理", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(fondsService.deleteFondsByIds(ids));
    }
}
