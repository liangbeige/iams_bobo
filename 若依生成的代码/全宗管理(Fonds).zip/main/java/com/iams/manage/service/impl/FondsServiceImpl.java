package com.iams.manage.service.impl;

import java.util.List;
import com.iams.common.utils.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.iams.manage.mapper.FondsMapper;
import com.iams.manage.domain.Fonds;
import com.iams.manage.service.IFondsService;

/**
 * 全宗管理Service业务层处理
 * 
 * @author zhjm
 * @date 2025-01-05
 */
@Service
public class FondsServiceImpl implements IFondsService 
{
    @Autowired
    private FondsMapper fondsMapper;

    /**
     * 查询全宗管理
     * 
     * @param id 全宗管理主键
     * @return 全宗管理
     */
    @Override
    public Fonds selectFondsById(Long id)
    {
        return fondsMapper.selectFondsById(id);
    }

    /**
     * 查询全宗管理列表
     * 
     * @param fonds 全宗管理
     * @return 全宗管理
     */
    @Override
    public List<Fonds> selectFondsList(Fonds fonds)
    {
        return fondsMapper.selectFondsList(fonds);
    }

    /**
     * 新增全宗管理
     * 
     * @param fonds 全宗管理
     * @return 结果
     */
    @Override
    public int insertFonds(Fonds fonds)
    {
        fonds.setCreateTime(DateUtils.getNowDate());
        return fondsMapper.insertFonds(fonds);
    }

    /**
     * 修改全宗管理
     * 
     * @param fonds 全宗管理
     * @return 结果
     */
    @Override
    public int updateFonds(Fonds fonds)
    {
        fonds.setUpdateTime(DateUtils.getNowDate());
        return fondsMapper.updateFonds(fonds);
    }

    /**
     * 批量删除全宗管理
     * 
     * @param ids 需要删除的全宗管理主键
     * @return 结果
     */
    @Override
    public int deleteFondsByIds(Long[] ids)
    {
        return fondsMapper.deleteFondsByIds(ids);
    }

    /**
     * 删除全宗管理信息
     * 
     * @param id 全宗管理主键
     * @return 结果
     */
    @Override
    public int deleteFondsById(Long id)
    {
        return fondsMapper.deleteFondsById(id);
    }
}
