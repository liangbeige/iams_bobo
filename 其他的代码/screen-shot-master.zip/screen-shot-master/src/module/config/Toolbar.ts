export default [
  {
    id: 1,
    title: "square"
  },
  {
    id: 2,
    title: "round"
  },
  {
    id: 3,
    title: "right-top"
  },
  {
    id: 4,
    title: "brush"
  },
  {
    id: 5,
    title: "mosaicPen"
  },
  {
    id: 6,
    title: "text"
  },
  {
    id: 7,
    title: "separateLine"
  },
  {
    id: 8,
    title: "save"
  }
];
